# env-vault

Production-oriented encrypted environment secrets for Node.js.

## Quick start

```bash
npm install env-vault
npx env-vault init
npx env-vault encrypt
npx env-vault run -- node server.js
```

`env-vault` uses Node.js cryptographic primitives, AES-256-GCM authenticated encryption,
and scrypt password-based key derivation. It is intentionally not a custom cryptography
implementation.

## CLI

```text
env-vault init
env-vault encrypt [--input .env] [--output .env.vault]
env-vault decrypt [--input .env.vault] [--output .env]
env-vault run -- <command> [args...]
env-vault rotate
env-vault status
env-vault version
```

The master password can be supplied interactively or through `ENV_VAULT_PASSWORD`.
For CI, prefer a secret injected by your CI provider rather than committing credentials.

## SDK

```ts
import { loadSecrets, encrypt, decrypt } from 'env-vault';

await loadSecrets({ vaultPath: '.env.vault' });

const blob = await encrypt('hello', 'password');
const plaintext = await decrypt(blob, 'password');
```

## Threat model

This package protects vault contents at rest and detects ciphertext tampering.
It does not protect secrets after your application has loaded them into memory, from a
compromised host, malicious dependencies, a malicious process with sufficient privileges,
or from a leaked master password/key.

Before adopting this in a high-assurance environment, perform an independent security review.
